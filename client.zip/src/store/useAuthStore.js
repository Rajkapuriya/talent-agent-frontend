import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export const useAuthStore = create(
    persist(
        (set) => ({
            token: null,
            user: null,

            setAuth: (token, user) => set({ token, user }),

            logout: () => {
                set({ token: null, user: null });
                window.location.href = '/login';
            },
        }),
        {
            name: 'talent_agent_auth',    // localStorage key
            partialize: (s) => ({ token: s.token, user: s.user }),
        }
    )
);